set +e
run_dir="$1"; shift
if [ -n "$NANOCLAW_CGROUP_DIR" ]; then base="$NANOCLAW_CGROUP_DIR"
else base="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"; fi
cat "$base/memory.max" > "$run_dir/memory.max"
cat "$base/memory.events" > "$run_dir/events-before"
"$@" > "$run_dir/stdout" 2> "$run_dir/stderr"
code=$?
cat "$base/memory.events" > "$run_dir/events-after"
cat "$base/memory.peak" > "$run_dir/memory.peak"
exit "$code"
